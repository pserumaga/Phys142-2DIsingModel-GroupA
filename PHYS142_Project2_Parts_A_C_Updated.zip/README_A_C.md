# PHYS 142 Final Project 2 — Parts A and C

**Marcus Palombi-Long** · Parts A and C contribution

This package extends, but does **not overwrite**, the group's `ising.ipynb`.
The source notebook pasted into chat had 13 cells. Its Ising spin-flip formula
already included magnetic field B correctly. Its energy function lacked a
`return`, and its runner recorded magnetization but not energy.

## Files

* `ising_ac_core.py`: validated single spin Metropolis engine with total energy
  and magnetization tracking, periodic boundaries, Numba, deterministic seeds.
* `analysis.py`: autocorrelation, blocking diagnostics, blocked jackknife for
  susceptibility and heat capacity. This is the analysis module developed
  earlier in our conversation.
* `run_parts_a_c.py`: plots and CSV outputs for Part A and Part C.
* `test_parts_a_c.py`: checks exact delta E and energy tracking.
* `ising_A_C_extension.ipynb`: Jupyter companion that calls the files above.

## Run on macOS

Place the files in the **same folder** as your team's `ising.ipynb`, keeping
existing team work intact. Use the Python 3.12 interpreter you verified:

```bash
cd /path/to/your/project
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 -m pip install numpy numba matplotlib
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 test_parts_a_c.py
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 run_parts_a_c.py --part both --mode pilot
```

When code and diagnostics work, run research cases individually:

```bash
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 run_parts_a_c.py --part A --mode research
/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 run_parts_a_c.py --part C --mode research
```

`--mode pilot` is explicitly **NOT final data**. Long research runs are still
only candidates for the report: inspect equilibration, independent chains,
autocorrelation windows, and blocking plateaus before claiming convergence.

Each invocation creates a `results_pilot` or `results_research` folder. If you
run A and then C to the same folder, the A and C output filenames are distinct.

## Assignment deliverables

### Part A — L=100

* `A_initial_state_traces.png`: compares up versus random starts at T=2, B=0.
* `A_tau_vs_T.png`: integrated autocorrelation time of **signed m** versus T
  with reference critical temperature 2.269.
* `A_chain_diagnostics.csv`: chains, seeds, initial states, acceptance, m,
  tau, ACF window validity.
* `A_field_checks.csv`: representative positive and negative fields.
* `A_tau_summary.csv`: mean and range of valid chain tau estimates.

Discuss where burn-in and retained lengths are insufficient. In particular,
large tau near Tc means a large part of successive sampling is redundant.
Autocorrelation estimates that hit the maximum lag limit are excluded.

### Part C — L=20,50,100 and B=0

* `C_abs_m_vs_T.png`: mean absolute magnetization versus T.
* `C_chi_vs_T.png`: susceptibility per spin versus T.
* `C_heat_capacity_per_spin_vs_T.png`: heat capacity per spin versus T.
* `C_finite_size_results.csv`: all values, jackknife errors where supportable,
  temperature, L, seeds, and the reason for any skipped uncertainty estimate.

Use the professor's estimator:

```text
chi = L**2 / T * (mean(m**2) - mean(abs(m))**2)
C / L**2 = (mean(E**2) - mean(E)**2) / (L**2 * T**2)
```

`E` is **total** energy. Energies measured at B=0 must use B=0, and energy
and magnetization must be sampled on the exact same sweeps.

Important: The existing `analysis.py` selects a conservative automatic block
size using several observable autocorrelation times. If it cannot form enough
blocks (or the autocorrelation window is truncated), the runner flags that
result, marks it with a cross in plots, and **does not invent an error bar**.
Extend the sampling and compare the blocking error versus block size to check
for a plateau. Even an automatically marked `ready` point needs inspection.

## Important bugs in the source notebook

1. The notebook's `total_energy(spins,B)` calculates energy but doesn't
   `return energy`. Correct if teammates intend to use it.
2. Its `advance_ising` returns magnetization and accepted count but not energy.
   Part C needs total energy at every retained sweep.
3. A uses T=2, B=1 and 1000 sweeps (only 200 designated as burn-in). The
   professor requires several T and B and a T scan of tau_int at **B=0**;
   these short parameters are not justified as production settings.
4. Notebook's Part B line is missing a B argument to `run_ising`, so it will
   raise `TypeError`. Tell the teammate responsible for B.
5. The team's notebook has a different existing seed from yours. Agree with
   group which reproducible seed scheme and final data are canonical.

## Code mapping

* `ising_ac_core.total_energy` — whole lattice Hamiltonian, count each bond once.
* `ising_ac_core.flip_energy` — local ΔE for spin flip with field B.
* `ising_ac_core._metropolis_trace` — one Metropolis sweep is L**2 random attempts;
  record both m and total energy E after each sweep.
* `ising_ac_core.simulate_chain` — initializes a reproducible run and removes
  burn-in from returned m, E arrays.
* `analysis.correlation_diagnostics` — A, integrated autocorrelation time.
* `analysis.analyze_ising_chains` — C, block jackknife across independent chains.

This is not a replacement for the full group project: Part B is owned by
another group member, and Part D interprets the combined phase diagram.
