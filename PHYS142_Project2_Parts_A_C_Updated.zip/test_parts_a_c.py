"""Fast correctness tests for the team's Ising project extension."""
import numpy as np
from ising_ac_core import total_energy, flip_energy, simulate_chain
from analysis import analyze_ising_chains, correlation_diagnostics


def run_tests():
    rng = np.random.default_rng(18)
    for L in (4, 5, 20):
        for B in (-0.4, 0.0, 0.3):
            spins = rng.choice(np.array([-1, 1],dtype=np.int8), size=(L,L))
            for i, j in ((0,0),(L-1,2),(L//2,L//2)):
                e0 = total_energy(spins, B)
                delta = flip_energy(spins, B, i, j)
                test = spins.copy()
                test[i, j] *= -1
                e1 = total_energy(test, B)
                assert np.isclose(e1-e0, delta, atol=1e-10), (L,B,i,j,delta,e1-e0)
    aligned = np.ones((8, 8), dtype=np.int8)
    assert np.isclose(total_energy(aligned,0), -128)
    assert np.isclose(total_energy(aligned,0.25),-144)
    assert np.isclose(flip_energy(aligned,0.25,0,0),8.5)
    a = simulate_chain(8, 2.3, 0.2, 200, 600, 418, init='random')
    b = simulate_chain(8, 2.3, 0.2, 200, 600, 418, init='random')
    assert np.array_equal(a['m'], b['m']) and np.array_equal(a['E'],b['E'])
    assert len(a['m']) == 600 and len(a['m_trace'])==801
    assert np.isclose(a['E'][-1],total_energy(a['final_spins'],0.2))
    assert np.isclose(a['m'][-1],a['final_spins'].mean())
    assert 0 <= a['acceptance'] <= 1
    # Independent sample sanity: autocorrelation should be close to 1/2.
    d = correlation_diagnostics(np.random.default_rng(142).normal(size=30000))
    assert 0.4 <= d.tau_int <= 1.5
    # Statistical results need enough sweeps per correlated block.
    a = simulate_chain(8, 3.0, 0, 200, 3000, 10)
    b = simulate_chain(8, 3.0, 0, 200, 3000, 11)
    result = analyze_ising_chains([a['m'],b['m']], [a['E'],b['E']], T=3.0,L=8,
                                  block_size=200, min_blocks=16)
    assert result['chi']>=0 and result['heat_capacity_per_spin']>=0
    assert result['n_blocks']==30
    print('PASS: periodic boundaries, ΔE, energy tracking, reproducibility,')
    print('      burn-in slicing, autocorrelation, blocked jackknife integration')


if __name__ == '__main__':
    run_tests()
