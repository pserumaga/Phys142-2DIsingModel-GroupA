"""Run assigned PHYS 142 Project 2 Parts A and C with teammate's Ising physics.

Project contribution: Marcus Palombi-Long (Parts A and C).

Usage
-----
python run_parts_a_c.py --part both --mode pilot
python run_parts_a_c.py --part A --mode research
python run_parts_a_c.py --part C --mode research

PILOT results validate integration, not statistical convergence. Research mode
performs longer runs, but a statistic is only marked 'ready' when the analysis
finds sufficient correlated blocks; inspect diagnostics before final reporting.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import warnings

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from ising_ac_core import simulate_chain
from analysis import analyze_ising_chains, correlation_diagnostics

BASE_SEED = 200060418
TC = 2 / np.log(1 + np.sqrt(2))


def write_csv(path, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', newline='') as fh:
        out = csv.DictWriter(fh, fieldnames=keys)
        out.writeheader()
        for row in rows:
            out.writerow(row)


def make_plot(path, curves, ylabel, title, mode):
    """Draw each observable in its own graph, with uncertainty when supported."""
    fig, ax = plt.subplots(figsize=(7.5, 4.7))
    for L, points in sorted(curves.items()):
        good = [p for p in points if p['ready']]
        bad = [p for p in points if not p['ready']]
        if good:
            ax.errorbar([x['T'] for x in good], [x['mean'] for x in good],
                        yerr=[x['err'] for x in good], fmt='o-', capsize=2,
                        label=f'L={L} (blocked jackknife)')
        if bad:
            ax.scatter([x['T'] for x in bad], [x['mean'] for x in bad],
                       marker='x', s=32, label=f'L={L} (insufficient blocks)')
    ax.axvline(TC, color='0.4', linestyle='--', label=f'Tc={TC:.3f}')
    ax.set(xlabel='Temperature T', ylabel=ylabel, title=title)
    ax.legend(fontsize=8)
    fig.text(.5, .01, 'Cross markers have no validated statistical error bar.'
             + (' PILOT RUN: NOT FINAL RESULTS.' if mode == 'pilot' else ''),
             ha='center', fontsize=9)
    fig.savefig(path, dpi=180, bbox_inches='tight')
    plt.close(fig)


def run_A(mode, outdir):
    if mode == 'pilot':
        temperatures = [2.0, 2.2, 2.269, 2.4, 3.0]
        burn, keep, n_chains = 250, 1100, 2
    else:
        temperatures = [1.8, 2.0, 2.10, 2.20, 2.24, 2.269, 2.30, 2.35, 2.4, 2.6, 3.0]
        burn, keep, n_chains = 4000, 25000, 4
    initial_states = ['up', 'random', 'down', 'random']
    rows, aggregated = [], []
    example = []
    for idx, T in enumerate(temperatures):
        taus = []
        for chain_id in range(n_chains):
            seed = BASE_SEED + 100000 + idx * 100 + chain_id
            init = initial_states[chain_id]
            run = simulate_chain(100, T, 0, burn, keep, seed, init)
            try:
                d = correlation_diagnostics(run['m'], max_lag=min(10000, keep//3))
                tau, truncated = d.tau_int, d.window_reached_limit
            except ValueError:
                tau, truncated = float('nan'), True
            if np.isfinite(tau) and not truncated:
                taus.append(tau)
            rows.append({'T':T,'B':0,'L':100,'chain':chain_id,'init':init,
                         'seed':seed,'burn':burn,'kept':keep,
                         'acceptance':run['acceptance'],
                         'mean_m':float(np.mean(run['m'])),
                         'mean_abs_m':float(np.mean(np.abs(run['m']))),
                         'tau_int_m':tau,'acf_truncated':truncated})
            if T == 2.0 and chain_id < 2:
                example.append((init, run['m_trace'].copy()))
        aggregated.append({'T':T,'n_valid_chains':len(taus),
                           'tau_mean':float(np.mean(taus)) if taus else float('nan'),
                           'tau_min':min(taus) if taus else float('nan'),
                           'tau_max':max(taus) if taus else float('nan')})
        print(f'A B=0 T={T:.3f}: {len(taus)}/{n_chains} reliable tau estimates', flush=True)
        write_csv(outdir/'A_chain_diagnostics.csv', rows)
        write_csv(outdir/'A_tau_summary.csv', aggregated)

    # A also requires sampling at different values of external B. The full
    # signed-magnetization scans belong to teammate's Part B; here we provide
    # representative B checks at two temperatures as a reproducibility record.
    field_tests = []
    for field_index, (T, B, init) in enumerate([(2.0, -0.1, 'down'), (2.0, 0.1, 'up'),
                                                 (2.5, -0.1, 'down'), (2.5, 0.1, 'up')]):
        r = simulate_chain(100, T, B, burn, keep,
                           BASE_SEED + 200000 + field_index, init)
        field_tests.append({'T':T,'B':B,'mean_m':np.mean(r['m']),
                            'acceptance':r['acceptance'],'burn':burn,'kept':keep,
                            'initial_state':init})
    write_csv(outdir/'A_field_checks.csv',field_tests)
    x = np.array([r['T'] for r in aggregated]); y = np.array([r['tau_mean'] for r in aggregated]);
    lo = np.array([r['tau_min'] for r in aggregated]); hi = np.array([r['tau_max'] for r in aggregated])
    valid = np.isfinite(y)
    fig,ax=plt.subplots(figsize=(7.5,4.7))
    if valid.any():
        ax.errorbar(x[valid], y[valid], yerr=np.vstack((y[valid]-lo[valid],hi[valid]-y[valid])),
                    fmt='o-', capsize=3, label='Mean ± range across chains')
    ax.axvline(TC, linestyle='--',color='0.4',label=f'Tc={TC:.3f}')
    ax.set(xlabel='Temperature T (B=0)',ylabel='Integrated autocorrelation time of signed m (sweeps)',
           title='Part A: Critical slowing down, L=100')
    ax.legend()
    if mode=='pilot': fig.text(.5,.01,'PILOT RUN: NOT FINAL RESULTS',ha='center',fontsize=9)
    fig.savefig(outdir/'A_tau_vs_T.png',dpi=180,bbox_inches='tight');plt.close(fig)
    if example:
        fig,ax=plt.subplots(figsize=(7.5,4.7))
        for label,trace in example:ax.plot(np.arange(len(trace)),trace,label=f'Initial {label}',alpha=.8)
        ax.axvspan(0,burn,alpha=.14,color='gray',label='Discarded burn in')
        ax.set(xlabel='Sweep',ylabel='Signed magnetization per spin',
               title='Part A: Dependence on initial configuration, L=100, T=2, B=0')
        ax.legend()
        if mode=='pilot':fig.text(.5,.01,'PILOT RUN: NOT FINAL RESULTS',ha='center',fontsize=9)
        fig.savefig(outdir/'A_initial_state_traces.png',dpi=180,bbox_inches='tight');plt.close(fig)
    return {'A_taus':aggregated,'field_checks':field_tests}


def raw_moments(m_chains, E_chains,T,L):
    m=np.concatenate(m_chains);e=np.concatenate(E_chains);n=L*L
    return {'abs_m':float(np.abs(m).mean()),
            'chi':float(n/T*(np.mean(m*m)-np.mean(np.abs(m))**2)),
            'heat_capacity_per_spin':float(np.var(e)/(n*T*T))}


def run_C(mode,outdir):
    if mode == 'pilot':
        temperatures=[2.0, 2.2, 2.269, 2.4, 2.8]
        burn, keep, n_chains=250, 1100, 2
    else:
        temperatures=[1.8, 2.0, 2.10, 2.20, 2.24, 2.269, 2.30, 2.35, 2.40, 2.5, 2.7, 3.0]
        burn, keep, n_chains=4000, 30000, 4
    sizes=[20, 50, 100]
    results=[]
    graphs={key:{} for key in ('abs_m','chi','heat_capacity_per_spin')}
    for L in sizes:
        for ti,T in enumerate(temperatures):
            m_chains=[];E_chains=[];starts=[]
            for ci in range(n_chains):
                init=['up','random','down','random'][ci]
                seed=BASE_SEED+300000+L*1000+ti*100+ci
                r=simulate_chain(L,T,0.0,burn,keep,seed,init)
                m_chains.append(r['m']);E_chains.append(r['E'])
                starts.append({'seed':seed,'init':init,'acceptance':r['acceptance']})
            row={'T':T,'L':L,'burn':burn,'kept_per_chain':keep,
                 'n_chains':n_chains,'ready':False,'seeds':';'.join(str(s['seed']) for s in starts)}
            row.update(raw_moments(m_chains,E_chains,T,L))
            try:
                with warnings.catch_warnings(record=True) as ws:
                    warnings.simplefilter('always')
                    d=analyze_ising_chains(m_chains,E_chains,T=T,L=L,
                                           min_blocks=16,block_factor=10,
                                           max_lag=min(10000,keep//3))
                truncated=any(any(values) for values in d['acf_window_hit_limit'].values())
                if truncated:
                    row['reason']='ACF lag window truncated; increase chain lengths'
                else:
                    row.update({key:d[key] for key in (
                        'm','m_err','abs_m','abs_m_err','chi','chi_err',
                        'heat_capacity_per_spin','heat_capacity_per_spin_err',
                        'energy_per_spin','energy_per_spin_err','block_size','n_blocks')})
                    row['ready']=True
                    row['reason']='Ready for inspection: verify block plateau and chain agreement'
            except ValueError as exc:
                row['reason']=str(exc)
            results.append(row)
            for key in graphs:
                graphs[key].setdefault(L,[]).append({'T':T,'mean':row[key],
                    'err':row.get(key+'_err',float('nan')),'ready':row['ready']})
            print(f'C L={L} T={T:.3f}: '+('blocked jackknife available' if row['ready'] else 'needs more sampling'),flush=True)
            write_csv(outdir/'C_finite_size_results.csv',results)
    names={'abs_m':r'Mean absolute magnetization <|m|>',
           'chi':r'Susceptibility per spin chi',
           'heat_capacity_per_spin':r'Heat capacity per spin c'}
    for key in graphs:
        make_plot(outdir/('C_'+key+'_vs_T.png'),graphs[key],names[key],
                  'Part C: Finite size comparison',mode)
    return {'C_conditions':len(results),'C_ready':sum(r['ready'] for r in results)}


def _json_safe(x):
    # Ensure valid strict JSON even if a diagnostic is undefined.
    if isinstance(x, dict):
        return {str(k): _json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_json_safe(v) for v in x]
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating, float)):
        f = float(x)
        return f if np.isfinite(f) else None
    return x


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--part',choices=['A','C','both'],default='both')
    ap.add_argument('--mode',choices=['pilot','research'],default='pilot')
    ap.add_argument('--output',default=None)
    args=ap.parse_args()
    outdir=Path(args.output or ('results_'+args.mode)).resolve()
    outdir.mkdir(parents=True,exist_ok=True)
    print('Writing output to',outdir)
    summary={'mode':args.mode,'note':'Pilot values are NOT suitable for final scientific conclusions.'}
    if args.part in ('A','both'):summary.update(run_A(args.mode,outdir))
    if args.part in ('C','both'):summary.update(run_C(args.mode,outdir))
    (outdir/'run_summary.json').write_text(json.dumps(_json_safe(summary),indent=2,allow_nan=False))
    print('Completed. Inspect CSV diagnostics and PNG graphs; never use points flagged as insufficient.')


if __name__=='__main__':
    main()
