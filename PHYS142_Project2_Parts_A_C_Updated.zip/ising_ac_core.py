"""PHYS 142 Final Project 2: Ising sampler for Parts A and C.

Project contribution: Marcus Palombi-Long (Parts A and C).

Built to work beside the team's existing ising.ipynb and analysis.py.
The spin flip energy follows the notebook's original definition, including B.
New features: correct total-energy return; O(1) energy and magnetization
tracking; reproducible seeds; separate equilibration and retained samples.

Units J = kB = 1. Energy refers to the TOTAL system energy, not energy/spin.
A Monte Carlo sweep = L*L attempted single-spin flips with replacement.
"""
from __future__ import annotations
import numpy as np
from numba import njit

J = 1.0
KB = 1.0


@njit
def total_energy(spins: np.ndarray, B: float) -> float:
    """Total E = -J sum over each bond ONCE - B sum of spins.

    Summing only right and down bonds handles periodic boundaries and avoids
    the original team's extra divide-by-two loop. The original implementation
    omitted `return energy` and therefore always returned None.
    """
    L = spins.shape[0]
    E = 0.0
    for i in range(L):
        for j in range(L):
            s = spins[i, j]
            E -= J * s * (spins[(i + 1) % L, j] + spins[i, (j + 1) % L])
            E -= B * s
    return E


@njit
def flip_energy(spins: np.ndarray, B: float, i: int, j: int) -> float:
    """Change in TOTAL energy for proposing spin(i,j) -> -spin(i,j).

    ΔE = 2*s*(J*(up+down+left+right) + B).
    """
    L = spins.shape[0]
    s = spins[i, j]
    neighbors = (spins[(i - 1) % L, j] + spins[(i + 1) % L, j]
                 + spins[i, (j - 1) % L] + spins[i, (j + 1) % L])
    return 2.0 * s * (J * neighbors + B)


@njit
def _metropolis_trace(spins, T, B, sweeps, rng):
    """Mutates spins; returns arrays of m and total E, including t=0.

    Calculate ΔE before a flip and update E += ΔE only if accepted.
    Calculate M += -2*s on acceptance, avoiding expensive full lattice sums.
    """
    L = spins.shape[0]
    n = L * L
    m = np.empty(sweeps + 1, dtype=np.float64)
    E = np.empty(sweeps + 1, dtype=np.float64)
    M = int(np.sum(spins))
    current_E = total_energy(spins, B)
    m[0] = M / n
    E[0] = current_E
    accepted = 0
    for sweep in range(1, sweeps + 1):
        for _ in range(n):
            i = rng.integers(0, L)
            j = rng.integers(0, L)
            s = spins[i, j]
            dE = flip_energy(spins, B, i, j)
            if dE <= 0 or rng.random() < np.exp(-dE / (KB * T)):
                spins[i, j] = -s
                M -= 2 * s
                current_E += dE
                accepted += 1
        m[sweep] = M / n
        E[sweep] = current_E
    return m, E, accepted


def simulate_chain(L: int, T: float, B: float, burn: int, keep: int,
                   seed: int, init: str = 'random') -> dict:
    """Run a reproducible Metropolis chain.

    Retained outputs m/E exclude ALL burn-in; raw_trace contains the initial
    sample, the burn-in trajectory and the measurement trajectory for A plots.
    """
    if int(L) != L or L < 4:
        raise ValueError('L must be an integer >= 4')
    if not np.isfinite(T) or T <= 0 or not np.isfinite(B):
        raise ValueError('T must be positive and T/B finite')
    if int(burn) != burn or int(keep) != keep or burn < 0 or keep < 1:
        raise ValueError('burn must be >=0 and keep must be >=1 integers')
    if init not in ('up', 'down', 'random'):
        raise ValueError('init must be up, down, or random')
    L, burn, keep = int(L), int(burn), int(keep)
    rng = np.random.default_rng(int(seed))
    if init == 'up':
        spins = np.ones((L, L), dtype=np.int8)
    elif init == 'down':
        spins = -np.ones((L, L), dtype=np.int8)
    else:
        spins = (2 * rng.integers(0, 2, size=(L, L)) - 1).astype(np.int8)
    m, E, accepted = _metropolis_trace(spins, float(T), float(B), burn+keep, rng)
    return {
        'm': m[burn+1:].copy(), 'E': E[burn+1:].copy(),
        'm_trace': m, 'E_trace': E,
        'acceptance': accepted/((burn+keep)*L*L),
        'L': L, 'T': float(T), 'B': float(B), 'burn': burn,
        'keep': keep, 'seed': int(seed), 'init': init,
        'final_spins': spins.copy(),
    }
